package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MyVibesScreen(onVideoClick: (String) -> Unit) {
    val myVibeVideos = mockVideos.filter { it.channel.isJoined }
    
    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "My Vibes",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )
        
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(myVibeVideos) { video ->
                VideoCard(video = video, onClick = { onVideoClick(video.id) })
            }
        }
    }
}
