package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onVideoClick: (String) -> Unit) {
    val categories = listOf("All", "Music", "Gaming", "News", "Tech")
    var selectedCategory by remember { mutableStateOf(categories[0]) }

    val trendingVideos = remember(mockVideos.toList()) { 
        mockVideos.sortedByDescending { it.viralScore }.take(3) 
    }
        
    // Sort logic: category match > viral score
    val feedVideos = remember(selectedCategory, mockVideos.toList()) {
        val baseList = if (selectedCategory == "All") mockVideos else mockVideos.filter { it.category == selectedCategory }
        baseList.sortedByDescending { it.viralScore }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { category ->
                FilterChip(
                    selected = selectedCategory == category,
                    onClick = { selectedCategory = category },
                    label = { Text(category) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.onBackground,
                        selectedLabelColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        }

        if (mockVideos.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                if (selectedCategory == "All" && trendingVideos.isNotEmpty()) {
                    item {
                        Text(
                            text = "🔥 Trending Now",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    items(trendingVideos) { video ->
                        VideoCard(video = video, onClick = { onVideoClick(video.id) })
                    }
                    item {
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Text(
                            text = "Because you watched ${trendingVideos.firstOrNull()?.category ?: "All"}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }

                items(feedVideos) { video ->
                    VideoCard(video = video, onClick = { onVideoClick(video.id) })
                }
            }
        }
    }
}
