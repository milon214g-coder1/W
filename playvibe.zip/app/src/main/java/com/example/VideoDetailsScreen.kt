package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

import androidx.compose.foundation.clickable
import kotlinx.coroutines.delay

@Composable
fun VideoDetailsScreen(videoId: String, onNavigateUp: () -> Unit, onViewSound: (String) -> Unit, onVideoClick: (String) -> Unit) {
    val videoIndex = mockVideos.indexOfFirst { it.id == videoId }
    val video = if (videoIndex != -1) mockVideos[videoIndex] else mockVideos.firstOrNull()
    if (video == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    var isJoined by remember { mutableStateOf(video.channel.isJoined) }

    var isPlaying by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0f) }

    LaunchedEffect(isPlaying) {
        while (isPlaying && progress < 1f) {
            delay(1000)
            progress += 0.05f
            if (progress >= 1f) isPlaying = false
        }
    }
    
    LaunchedEffect(videoId) {
        mockWatchHistory.removeAll { it.id == video.id }
        mockWatchHistory.add(video)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (video.videoUrl.isNotEmpty()) {
            VideoPlayerView(
                videoUrl = video.videoUrl,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
            )
        } else {
            // Mock Video Player fallback
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
                    .clickable { isPlaying = !isPlaying },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = "Video Thumbnail",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    alpha = if (isPlaying) 0.5f else 0.8f
                )
                if (!isPlaying) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(64.dp))
                }
                
                LinearProgressIndicator(
                    progress = progress,
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.DarkGray
                )
            }
        }
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = video.title,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${video.viewCount} views • ${video.uploadDate}",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    if (video.isCopyrightClaimed) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Icon(Icons.Filled.Warning, contentDescription = "Copyright", tint = MaterialTheme.colorScheme.onErrorContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Copyright Claim by ${video.originalOwnerChannelName}",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Channel Info & JoinVibe
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        AsyncImage(
                            model = video.channel.profileImageUrl,
                            contentDescription = "Channel Profile",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = video.channel.name,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "${video.channel.vibersCount} Vibers",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        JoinVibeButton(isJoined = isJoined, onClick = { isJoined = !isJoined })
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Actions
                    var showSaveMenu by remember { mutableStateOf(false) }
                    var showPlaylistDialog by remember { mutableStateOf(false) }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ActionButton(
                            icon = Icons.Filled.ThumbUp, 
                            label = formatCount(video.likesCount),
                            isActive = video.isLiked,
                            onClick = {
                                FirebaseManager.toggleLike(video.id, !video.isLiked)
                            }
                        )
                        ActionButton(icon = Icons.Filled.ThumbDown, label = "Dislike", onClick = { /* TODO */ })
                        ActionButton(icon = Icons.Filled.Share, label = "Share", onClick = { /* TODO */ })
                        Box {
                            ActionButton(icon = Icons.Filled.AddCircle, label = "Save", onClick = { showSaveMenu = true })
                            DropdownMenu(
                                expanded = showSaveMenu,
                                onDismissRequest = { showSaveMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Save to Watch Later") },
                                    onClick = {
                                        FirebaseManager.addToWatchLater(video.id)
                                        showSaveMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Save to Playlist") },
                                    onClick = {
                                        showSaveMenu = false
                                        showPlaylistDialog = true
                                    }
                                )
                            }
                        }
                    }
                    
                    if (showPlaylistDialog) {
                        AlertDialog(
                            onDismissRequest = { showPlaylistDialog = false },
                            title = { Text("Save to Playlist") },
                            text = {
                                Column {
                                    mockPlaylists.forEach { playlist ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    FirebaseManager.addToPlaylist(playlist.id, video.id)
                                                    showPlaylistDialog = false
                                                }
                                                .padding(vertical = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(playlist.name)
                                        }
                                    }
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = { showPlaylistDialog = false }) {
                                    Text("Cancel")
                                }
                            }
                        )
                    }

                    if (video.soundId != null) {
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = { onViewSound(video.soundId) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.MusicNote, contentDescription = "Sound")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("View Sound")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Description
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = video.description,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Comments", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            items(mockComments) { comment ->
                CommentItem(comment = comment)
            }
            
            item {
                 Spacer(modifier = Modifier.height(24.dp))
                 Text("Recommended", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 16.dp))
                 Spacer(modifier = Modifier.height(8.dp))
            }
            
            items(mockVideos.filter { it.id != videoId }) { recVideo ->
                VideoCard(video = recVideo, onClick = { onVideoClick(recVideo.id) })
            }
        }
    }
}

@Composable
fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, isActive: Boolean = false, onClick: () -> Unit = {}) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }.padding(8.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, fontSize = 12.sp, color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
fun CommentItem(comment: Comment) {
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        AsyncImage(
            model = comment.authorProfileUrl,
            contentDescription = "Author",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(32.dp).clip(CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = comment.authorName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = comment.timestamp, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = comment.text, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ThumbUp, contentDescription = "Like", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = comment.likesCount, fontSize = 12.sp)
                Spacer(modifier = Modifier.width(16.dp))
                Icon(Icons.Filled.ThumbDown, contentDescription = "Dislike", modifier = Modifier.size(16.dp))
            }
        }
    }
}
