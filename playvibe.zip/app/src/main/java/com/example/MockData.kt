package com.example

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

data class Video(
    val id: String,
    val title: String,
    val thumbnailUrl: String,
    val channel: Channel,
    val viewCount: String,
    val uploadDate: String,
    val duration: String,
    val videoUrl: String = "",
    val description: String = "This is a detailed description of the video. It can contain links and hashtags #PlayVibe #Awesome",
    val likesCount: Int = 10000,
    val isLiked: Boolean = false,
    val viralScore: Int = 0,
    val category: String = "All",
    val soundId: String? = null,
    val isCopyrightClaimed: Boolean = false,
    val originalOwnerChannelName: String? = null
)

data class Channel(
    val id: String,
    val name: String,
    val profileImageUrl: String,
    val vibersCount: String,
    val isJoined: Boolean = false
)

data class Comment(
    val id: String,
    val authorName: String,
    val authorProfileUrl: String,
    val text: String,
    val timestamp: String,
    val likesCount: String
)

data class Sound(
    val id: String,
    val name: String,
    val originalChannelName: String
)

val mockChannels = mutableStateListOf(
    Channel("c1", "TechVibe", "https://picsum.photos/seed/techvibe/100/100", "1.2M", false),
    Channel("c2", "MusicVibe", "https://picsum.photos/seed/musicvibe/100/100", "5.4M", true),
    Channel("c3", "GamingVibe", "https://picsum.photos/seed/gamingvibe/100/100", "800K", false),
    Channel("c4", "NewsVibe", "https://picsum.photos/seed/newsvibe/100/100", "2.1M", false)
)

val mockSounds = listOf(
    Sound("sound1", "Epic Background Music", "MusicVibe"),
    Sound("sound2", "Funny Meme Sound", "ComedyCentral")
)

val mockVideos = mutableStateListOf(
    Video(
        id = "v1",
        title = "Building a YouTube Clone in Android Compose",
        thumbnailUrl = "https://picsum.photos/seed/vid1/600/300",
        channel = mockChannels[0],
        viewCount = "100K",
        uploadDate = "2 days ago",
        duration = "10:05",
        viralScore = 85,
        category = "Tech",
        soundId = "sound1"
    ),
    Video(
        id = "v2",
        title = "Top 10 Music Hits 2026",
        thumbnailUrl = "https://picsum.photos/seed/vid2/600/300",
        channel = mockChannels[1],
        viewCount = "2M",
        uploadDate = "1 week ago",
        duration = "3:45",
        viralScore = 95,
        category = "Music",
        soundId = "sound1"
    ),
    Video(
        id = "v3",
        title = "Minecraft Epic Base Build",
        thumbnailUrl = "https://picsum.photos/seed/vid3/600/300",
        channel = mockChannels[2],
        viewCount = "500K",
        uploadDate = "1 month ago",
        duration = "25:30",
        viralScore = 60,
        category = "Gaming"
    ),
    Video(
        id = "v4",
        title = "Breaking News: AI takes over",
        thumbnailUrl = "https://picsum.photos/seed/vid4/600/300",
        channel = mockChannels[3],
        viewCount = "1.5M",
        uploadDate = "3 hours ago",
        duration = "5:00",
        viralScore = 99,
        category = "News"
    )
)

val mockShorts = mutableStateListOf(
    Video(
        id = "s1",
        title = "Funny Cat Compilation #Shorts",
        thumbnailUrl = "https://picsum.photos/seed/short1/400/800",
        channel = mockChannels[0],
        viewCount = "5M",
        uploadDate = "1 day ago",
        duration = "0:30",
        viralScore = 90
    ),
    Video(
        id = "s2",
        title = "Incredible Magic Trick",
        thumbnailUrl = "https://picsum.photos/seed/short2/400/800",
        channel = mockChannels[1],
        viewCount = "2M",
        uploadDate = "2 days ago",
        duration = "0:45",
        viralScore = 70
    ),
    Video(
        id = "s3",
        title = "Life Hack you must know",
        thumbnailUrl = "https://picsum.photos/seed/short3/400/800",
        channel = mockChannels[2],
        viewCount = "10M",
        uploadDate = "5 hours ago",
        duration = "0:15",
        viralScore = 98,
        soundId = "sound2"
    )
)

val mockComments = listOf(
    Comment("cm1", "User1", "https://picsum.photos/seed/u1/100/100", "This is an amazing video!", "1 day ago", "120"),
    Comment("cm2", "User2", "https://picsum.photos/seed/u2/100/100", "I learned so much, thanks for sharing.", "2 days ago", "50"),
    Comment("cm3", "User3", "https://picsum.photos/seed/u3/100/100", "Can you make a part 2?", "5 hours ago", "10")
)

var currentUserChannel by mutableStateOf(
    Channel(
        id = "my_channel",
        name = "Guest",
        profileImageUrl = "https://picsum.photos/seed/myprofile/150/150",
        vibersCount = "0",
        isJoined = false
    )
)

data class Notification(
    val id: String,
    val title: String,
    val message: String,
    val time: String,
    val imageUrl: String
)

val mockNotifications = listOf(
    Notification("n1", "New comment on your video", "User1 said: This is amazing!", "2 hours ago", "https://picsum.photos/seed/u1/100/100"),
    Notification("n2", "MusicVibe uploaded a new video", "Top 10 Music Hits 2026", "1 day ago", "https://picsum.photos/seed/musicvibe/100/100"),
    Notification("n3", "Your video got 100 likes", "Building a YouTube Clone in Android Compose", "2 days ago", "https://picsum.photos/seed/vid1/100/100")
)

data class Playlist(val id: String, val name: String, val videos: MutableList<Video>)

val mockWatchHistory = mutableStateListOf<Video>()
val mockWatchLater = mutableStateListOf<Video>()
val mockPlaylists = mutableStateListOf(
    Playlist("p1", "Favorites", mutableListOf(mockVideos[0], mockVideos[1])),
    Playlist("p2", "Watch Later Mix", mutableListOf(mockVideos[2]))
)

