package com.example

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Home)
    object Shorts : Screen("shorts", "Shorts", Icons.Filled.PlayArrow) // Should use a shorts-like icon
    object Upload : Screen("upload", "Upload", Icons.Filled.AddCircleOutline)
    object MyVibes : Screen("my_vibes", "My Vibes", Icons.Filled.Subscriptions)
    object You : Screen("you", "You", Icons.Filled.VideoLibrary)
}

val BottomNavScreens = listOf(
    Screen.Home,
    Screen.Shorts,
    Screen.Upload,
    Screen.MyVibes,
    Screen.You
)
