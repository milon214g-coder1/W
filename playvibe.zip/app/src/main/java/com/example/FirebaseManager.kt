package com.example

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.util.UUID

object FirebaseManager {
    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    val storage: FirebaseStorage by lazy { FirebaseStorage.getInstance() }
    
    private var isInitialized = false

    // Listen to Auth State
    fun listenToAuthState(onAuthStateChanged: (FirebaseUser?) -> Unit) {
        auth.addAuthStateListener { firebaseAuth ->
            onAuthStateChanged(firebaseAuth.currentUser)
        }
    }

    // Authentication
    suspend fun signInAnonymously(): Result<FirebaseUser> {
        return try {
            val result = auth.signInAnonymously().await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Create User Document
    suspend fun createUserDocument(user: FirebaseUser, displayName: String = "Guest", phone: String = "") {
        try {
            val channelRef = firestore.collection("channels").document(user.uid)
            val snapshot = channelRef.get().await()
            if (!snapshot.exists()) {
                val channelData = mapOf(
                    "channelName" to displayName,
                    "handle" to "@${displayName.replace(" ", "").lowercase()}${user.uid.take(4)}",
                    "avatarUrl" to "https://picsum.photos/seed/${user.uid}/150/150",
                    "subscriberCount" to "0",
                    "bio" to "New to PlayVibe!",
                    "joinDate" to System.currentTimeMillis(),
                    "phone" to phone
                )
                channelRef.set(channelData).await()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Upload Video to Storage
    suspend fun uploadVideo(uri: Uri, title: String, description: String, category: String, onProgress: (Float) -> Unit): Result<String> {
        return try {
            val user = auth.currentUser ?: throw Exception("Not authenticated")
            val videoId = UUID.randomUUID().toString()
            val videoRef = storage.reference.child("videos/$videoId.mp4")
            
            // Note: In a real app, we'd use a more robust upload mechanism.
            // For simplicity, we just putFile and await.
            videoRef.putFile(uri).await()
            val downloadUrl = videoRef.downloadUrl.await().toString()
            
            Result.success(downloadUrl)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun toggleLike(videoId: String, isLiked: Boolean) {
        val user = auth.currentUser ?: return
        val doc = firestore.collection("videos").document(videoId)
        
        try {
            firestore.runTransaction { transaction ->
                val snapshot = transaction.get(doc)
                if (snapshot.exists()) {
                    val currentLikes = snapshot.getLong("likeCount") ?: 0
                    val newLikes = if (isLiked) currentLikes + 1 else currentLikes - 1
                    transaction.update(doc, "likeCount", newLikes.coerceAtLeast(0))
                }
            }
            
            val userLiked = firestore.collection("users").document(user.uid).collection("likedVideos").document(videoId)
            if (isLiked) userLiked.set(mapOf("timestamp" to System.currentTimeMillis()))
            else userLiked.delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addToWatchHistory(videoId: String) {
        val user = auth.currentUser ?: return
        try {
            firestore.collection("users").document(user.uid).collection("history")
                .document(videoId).set(mapOf("timestamp" to System.currentTimeMillis()))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addToWatchLater(videoId: String) {
        val user = auth.currentUser ?: return
        try {
            firestore.collection("users").document(user.uid).collection("watchLater")
                .document(videoId).set(mapOf("timestamp" to System.currentTimeMillis()))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun createPlaylist(name: String, onComplete: () -> Unit = {}) {
        val user = auth.currentUser ?: return
        val playlistId = UUID.randomUUID().toString()
        try {
            firestore.collection("users").document(user.uid).collection("playlists")
                .document(playlistId).set(mapOf("name" to name)).addOnSuccessListener { onComplete() }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addToPlaylist(playlistId: String, videoId: String) {
        val user = auth.currentUser ?: return
        try {
            firestore.collection("users").document(user.uid).collection("playlists")
                .document(playlistId).collection("videos")
                .document(videoId).set(mapOf("timestamp" to System.currentTimeMillis()))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun initFirebaseData() {
        if (isInitialized) return
        isInitialized = true
        
        try {
            val user = auth.currentUser ?: return
            
            // 1. Listen to channels
            firestore.collection("channels").addSnapshotListener { channelSnapshot, _ ->
                if (channelSnapshot != null) {
                    val parsedChannels = channelSnapshot.documents.map { doc ->
                        Channel(
                            id = doc.id,
                            name = doc.getString("channelName") ?: "Unknown",
                            profileImageUrl = doc.getString("avatarUrl") ?: "https://picsum.photos/200",
                            vibersCount = doc.getString("subscriberCount") ?: "0",
                            isJoined = false
                        )
                    }
                    val channels = parsedChannels.associateBy { it.id }
                    
                    mockChannels.clear()
                    mockChannels.addAll(parsedChannels)
                    
                    channels[user.uid]?.let { channel ->
                        currentUserChannel = channel
                    }
                    
                    // Update videos with new channel info if needed
                    val currentVideos = mockVideos.toList()
                    if (currentVideos.isNotEmpty()) {
                        val updatedVideos = currentVideos.map { vid ->
                            val c = channels[vid.channel.id]
                            if (c != null && c != vid.channel) {
                                vid.copy(channel = c)
                            } else vid
                        }
                        mockVideos.clear()
                        mockVideos.addAll(updatedVideos)
                    }
                }
            }
            
            // 2. Listen to liked videos
            var likedIds = emptyList<String>()
            firestore.collection("users").document(user.uid).collection("likedVideos").addSnapshotListener { likesSnapshot, _ ->
                if (likesSnapshot != null) {
                    likedIds = likesSnapshot.documents.map { it.id }
                    
                    // Update current videos with like status
                    val currentVideos = mockVideos.toList()
                    if (currentVideos.isNotEmpty()) {
                        val updatedVideos = currentVideos.map { vid ->
                            val isLiked = likedIds.contains(vid.id)
                            if (vid.isLiked != isLiked) vid.copy(isLiked = isLiked) else vid
                        }
                        mockVideos.clear()
                        mockVideos.addAll(updatedVideos)
                    }
                }
            }
            
            // 3. Listen to videos
            firestore.collection("videos").addSnapshotListener { videoSnapshot, _ ->
                if (videoSnapshot != null) {
                    val channels = mockChannels.associateBy { it.id }
                    val parsedVideos = videoSnapshot.documents.map { doc ->
                        val uploaderId = doc.getString("uploaderChannelId") ?: ""
                        val channel = channels[uploaderId] ?: mockChannels.firstOrNull() ?: Channel("unknown", "Unknown", "", "0", false) // fallback
                        val vidId = doc.getString("id") ?: doc.id
                        Video(
                            id = vidId,
                            title = doc.getString("title") ?: "",
                            thumbnailUrl = doc.getString("thumbnailUrl") ?: "",
                            channel = channel,
                            viewCount = doc.getString("viewCount") ?: "0",
                            uploadDate = doc.getString("uploadDate") ?: "",
                            duration = doc.getString("duration") ?: "0:00",
                            videoUrl = doc.getString("videoUrl") ?: "",
                            description = doc.getString("description") ?: "",
                            likesCount = doc.getLong("likeCount")?.toInt() ?: 0,
                            isLiked = likedIds.contains(vidId),
                            viralScore = doc.getLong("viralScore")?.toInt() ?: 0,
                            category = doc.getString("category") ?: "All",
                            soundId = doc.getString("soundId"),
                            isCopyrightClaimed = doc.getBoolean("isCopyrightClaimed") ?: false,
                            originalOwnerChannelName = doc.getString("originalOwnerChannelName")
                        )
                    }
                    
                    if (parsedVideos.isNotEmpty()) {
                        mockVideos.clear()
                        mockVideos.addAll(parsedVideos)
                        
                        val shorts = parsedVideos.filter { it.duration == "0:00" }
                        if (shorts.isNotEmpty()) {
                            mockShorts.clear()
                            mockShorts.addAll(shorts)
                        }
                    }
                }
            }
            
            // 4. Listen to History
            firestore.collection("users").document(user.uid).collection("history").addSnapshotListener { histSnap, _ ->
                if (histSnap != null) {
                    val histIds = histSnap.documents.map { it.id }
                    val histVids = mockVideos.filter { histIds.contains(it.id) }
                    mockWatchHistory.clear()
                    mockWatchHistory.addAll(histVids)
                }
            }
            
            // 5. Listen to Watch Later
            firestore.collection("users").document(user.uid).collection("watchLater").addSnapshotListener { wlSnap, _ ->
                if (wlSnap != null) {
                    val wlIds = wlSnap.documents.map { it.id }
                    val wlVids = mockVideos.filter { wlIds.contains(it.id) }
                    mockWatchLater.clear()
                    mockWatchLater.addAll(wlVids)
                }
            }
            
            // 6. Listen to Playlists
            firestore.collection("users").document(user.uid).collection("playlists").addSnapshotListener { plSnap, _ ->
                if (plSnap != null) {
                    val newPlaylists = plSnap.documents.map { pDoc ->
                        val pName = pDoc.getString("name") ?: "Playlist"
                        Playlist(pDoc.id, pName, mutableListOf())
                        // Note: For simplicity, we are skipping the nested videos listener here, 
                        // as it requires more complex state management to avoid memory leaks.
                    }
                    mockPlaylists.clear()
                    mockPlaylists.addAll(newPlaylists)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
