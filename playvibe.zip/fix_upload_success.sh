#!/bin/bash
sed -i 's/FirebaseManager.firestore.collection("videos").document(videoId).set(videoData).await()/FirebaseManager.firestore.collection("videos").document(videoId).set(videoData).await()\n                            android.widget.Toast.makeText(context, "Upload successful!", android.widget.Toast.LENGTH_LONG).show()/' app/src/main/java/com/example/UploadScreen.kt
