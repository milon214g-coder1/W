#!/bin/bash
cat << 'INNER_EOF' > app/src/main/java/com/example/MainActivity.kt
package com.example

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PlayVibeApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun PlayVibeApp() {
    var isAuthenticated by remember { mutableStateOf(false) }
    var isCheckingAuth by remember { mutableStateOf(true) }

    val permissionsToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        listOf(android.Manifest.permission.READ_MEDIA_VIDEO, android.Manifest.permission.READ_MEDIA_IMAGES)
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        listOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
    } else {
        listOf(android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }
    
    val permissionsState = rememberMultiplePermissionsState(permissionsToRequest)
    var showPermissionRationale by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
        }
    }
    
    if (!permissionsState.allPermissionsGranted && permissionsState.shouldShowRationale) {
        showPermissionRationale = true
    }

    DisposableEffect(Unit) {
        val listener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { auth ->
            isAuthenticated = auth.currentUser != null
            isCheckingAuth = false
            if (isAuthenticated) {
                FirebaseManager.initFirebaseData()
            }
        }
        try {
            FirebaseManager.auth.addAuthStateListener(listener)
        } catch (e: Exception) {
            isCheckingAuth = false
        }
        
        onDispose {
            try {
                FirebaseManager.auth.removeAuthStateListener(listener)
            } catch (e: Exception) {}
        }
    }

    if (isCheckingAuth) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (!isAuthenticated) {
        AuthScreen(onAuthSuccess = { isAuthenticated = true })
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    var showUploadBottomSheet by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentRoute != Screen.Shorts.route && currentRoute?.startsWith("video/") == false) {
                TopAppBar(
                    title = { PlayVibeLogo() },
                    actions = {
                        IconButton(onClick = { /* Search */ }) {
                            Icon(Icons.Filled.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = { navController.navigate("notifications") }) {
                            Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground,
                        actionIconContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
        },
        bottomBar = {
            if (currentRoute?.startsWith("video/") == false) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.onBackground
                ) {
                    BottomNavScreens.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.label) },
                            label = { Text(screen.label) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                if (screen.route == Screen.Upload.route) {
                                    showUploadBottomSheet = true
                                } else {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(onVideoClick = { videoId ->
                    navController.navigate("video/$videoId")
                })
            }
            composable(Screen.Shorts.route) { ShortsScreen() }
            composable(Screen.Upload.route) { /* Handled by BottomSheet */ }
            composable(Screen.MyVibes.route) {
                MyVibesScreen(onVideoClick = { videoId ->
                    navController.navigate("video/$videoId")
                })
            }
            composable(Screen.You.route) { 
                YouScreen(
                    onChannelClick = { channelId -> 
                        navController.navigate("channel/$channelId")
                    },
                    onHistoryClick = { navController.navigate("history") },
                    onPlaylistsClick = { navController.navigate("playlists") },
                    onWatchLaterClick = { navController.navigate("watch_later") },
                    onLikedVideosClick = { navController.navigate("liked_videos") },
                    onSettingsClick = { navController.navigate("settings") }
                ) 
            }
            composable("history") {
                HistoryScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("playlists") {
                PlaylistsScreen(
                    onNavigateUp = { navController.navigateUp() },
                    onPlaylistClick = { playlistId ->
                        navController.navigate("playlist/$playlistId")
                    }
                )
            }
            composable("playlist/{playlistId}") { backStackEntry ->
                val playlistId = backStackEntry.arguments?.getString("playlistId") ?: ""
                PlaylistDetailsScreen(
                    playlistId = playlistId,
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("watch_later") {
                WatchLaterScreen(
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("liked_videos") {
                LikedVideosScreen(
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("settings") {
                SettingsScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("video/{videoId}") { backStackEntry ->
                val videoId = backStackEntry.arguments?.getString("videoId") ?: ""
                VideoDetailsScreen(
                    videoId = videoId,
                    onNavigateUp = { navController.navigateUp() },
                    onViewSound = { soundId ->
                        navController.navigate("sound/$soundId")
                    },
                    onVideoClick = { newVideoId ->
                        navController.navigate("video/$newVideoId")
                    }
                )
            }
            composable("sound/{soundId}") { backStackEntry ->
                val soundId = backStackEntry.arguments?.getString("soundId") ?: ""
                SoundDetailsScreen(
                    soundId = soundId,
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("notifications") {
                NotificationsScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("channel/{channelId}") { backStackEntry ->
                val channelId = backStackEntry.arguments?.getString("channelId") ?: ""
                ChannelScreen(
                    channelId = channelId,
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    },
                    onEditProfileClick = {
                        navController.navigate("edit_profile")
                    }
                )
            }
            composable("edit_profile") {
                EditProfileScreen(onNavigateUp = { navController.navigateUp() })
            }
        }
        
        var showUploadScreen by remember { mutableStateOf(false) }
        
        if (showUploadScreen) {
            UploadScreen(onDismiss = { showUploadScreen = false })
        }
        
        if (showUploadBottomSheet) {
            UploadBottomSheet(
                onDismiss = { showUploadBottomSheet = false },
                onSimulateUpload = { 
                    showUploadScreen = true 
                }
            )
        }
        
        if (showPermissionRationale) {
            AlertDialog(
                onDismissRequest = { showPermissionRationale = false },
                title = { Text("Permission Required") },
                text = { Text("Gallery and file access is needed so you can upload videos. Please grant the permission to enable uploading.") },
                confirmButton = {
                    TextButton(onClick = { 
                        showPermissionRationale = false
                        permissionsState.launchMultiplePermissionRequest()
                    }) {
                        Text("Grant")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showPermissionRationale = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
INNER_EOF
